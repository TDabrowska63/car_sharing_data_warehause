from generator import Generator
from generate_csv.create_zgloszenia import generate_zgloszenia


def main():

    generator = Generator(500, 100)

if __name__ == '__main__':
    main()
